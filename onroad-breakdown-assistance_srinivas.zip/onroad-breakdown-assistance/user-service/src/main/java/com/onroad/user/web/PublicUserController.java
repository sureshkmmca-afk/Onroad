package com.onroad.user.web;

import com.onroad.user.domain.UserProfile;
import com.onroad.user.repo.UserRepository;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/public")
@Validated
public class PublicUserController {

    private final UserRepository repo;

    public PublicUserController(UserRepository repo) {
        this.repo = repo;
    }

    public record CreateUserRequest(@NotBlank String name, @Email String email, @NotBlank String phone, @NotBlank String location) {}
    public record CreateUserResponse(Long id) {}

    @PostMapping("/users")
    public ResponseEntity<CreateUserResponse> create(@Validated @RequestBody CreateUserRequest req) {
        repo.findByEmail(req.email()).ifPresent(u -> { throw new IllegalArgumentException("User already exists"); });
        UserProfile u = new UserProfile();
        u.setName(req.name());
        u.setEmail(req.email());
        u.setPhone(req.phone());
        u.setLocation(req.location());
        u = repo.save(u);
        return ResponseEntity.ok(new CreateUserResponse(u.getId()));
    }
}
