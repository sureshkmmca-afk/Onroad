package com.onroad.user.web;

import com.onroad.user.repo.UserRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin")
public class AdminUserController {

    private final UserRepository repo;

    public AdminUserController(UserRepository repo) {
        this.repo = repo;
    }

    @GetMapping("/users")
    @PreAuthorize("hasRole('ADMIN')")
    public Object list() {
        return repo.findAll();
    }
}
