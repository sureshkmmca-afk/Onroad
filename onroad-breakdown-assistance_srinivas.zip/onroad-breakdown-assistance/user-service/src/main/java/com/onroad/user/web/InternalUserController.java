package com.onroad.user.web;

import com.onroad.user.repo.UserRepository;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/internal")
public class InternalUserController {

    private final UserRepository repo;

    public InternalUserController(UserRepository repo) {
        this.repo = repo;
    }

    @GetMapping("/users/{id}/exists")
    public Boolean exists(@PathVariable Long id) {
        return repo.existsById(id);
    }
}
