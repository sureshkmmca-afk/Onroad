package com.onroad.user;

import com.onroad.user.repo.UserRepository;
import com.onroad.user.web.PublicUserController.CreateUserRequest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {
                "spring.datasource.url=jdbc:h2:mem:userdb;MODE=PostgreSQL;DB_CLOSE_DELAY=-1",
                "spring.datasource.username=sa",
                "spring.datasource.password=",
                "spring.jpa.hibernate.ddl-auto=none",
                "spring.flyway.enabled=true",
                "security.jwt.secret=test-test-test-test-test-test-test-test"
        })
class UserServiceIntegrationTest {

    @Autowired TestRestTemplate rest;
    @Autowired UserRepository repo;

    @Test
    void createUser_publicEndpoint_works() {
        var req = new CreateUserRequest("Suresh", "suresh@example.com", "9999999999", "Bangalore");
        HttpHeaders h = new HttpHeaders();
        h.setContentType(MediaType.APPLICATION_JSON);
        var resp = rest.postForEntity("/api/v1/public/users", new HttpEntity<>(req, h), String.class);
        assertThat(resp.getStatusCode().is2xxSuccessful()).isTrue();
        assertThat(repo.findByEmail("suresh@example.com")).isPresent();
    }
}
