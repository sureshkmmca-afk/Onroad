# On Road Vehicle Breakdown Assistance — Microservices (NO DOCKER)

✅ **Microservices mandatory** — implemented.
✅ **No Docker required** — you run PostgreSQL locally and start services from IntelliJ/Maven.

**Tech:** Java 21, Spring Boot 3.3.2, Spring Cloud 2023.0.3, PostgreSQL, Maven.

---

## 1) Services & Ports

| Service | Port | DB |
|---|---:|---|
| discovery-server (Eureka) | 8761 | — |
| api-gateway (Gateway) | 8080 | — |
| auth-service | 9000 | authdb |
| user-service | 9001 | userdb |
| mechanic-service | 9002 | mechanicdb |
| request-service | 9003 | requestdb |
| feedback-service | 9004 | feedbackdb |

---

## 2) Prerequisites
- Java 21
- Maven 3.9+
- PostgreSQL installed locally

---

## 3) One-time DB setup (NO Docker)

### Option A (recommended): Run SQL script
Open `infra/sql/create-dbs.sql` in pgAdmin/psql and execute.

### Option B: Run manually
```sql
CREATE DATABASE authdb;
CREATE DATABASE userdb;
CREATE DATABASE mechanicdb;
CREATE DATABASE requestdb;
CREATE DATABASE feedbackdb;
```

Create a DB user (example):
```sql
CREATE USER onroad WITH ENCRYPTED PASSWORD 'onroad';
GRANT ALL PRIVILEGES ON DATABASE authdb TO onroad;
GRANT ALL PRIVILEGES ON DATABASE userdb TO onroad;
GRANT ALL PRIVILEGES ON DATABASE mechanicdb TO onroad;
GRANT ALL PRIVILEGES ON DATABASE requestdb TO onroad;
GRANT ALL PRIVILEGES ON DATABASE feedbackdb TO onroad;
```

---

## 4) Configure local DB + JWT Secret
Each service has `src/main/resources/application.yml` pointing to local Postgres.
Update if your postgres user/password differ.

Environment variable (recommended):
- `JWT_SECRET` (must be **>= 32 chars** for HS256)

Example:
```bash
set JWT_SECRET=change-me-change-me-change-me-change-me
```
(or Linux/Mac `export JWT_SECRET=...`)

---

## 5) Run the system (order matters)

### Start Eureka
```bash
mvn -pl discovery-server spring-boot:run
```

### Start Gateway
```bash
mvn -pl api-gateway spring-boot:run
```

### Start domain services
```bash
mvn -pl user-service spring-boot:run
mvn -pl mechanic-service spring-boot:run
mvn -pl auth-service spring-boot:run
mvn -pl request-service spring-boot:run
mvn -pl feedback-service spring-boot:run
```

URLs:
- Eureka: http://localhost:8761
- Gateway: http://localhost:8080

---

## 6) Default Admin
Created by Flyway migration in `auth-service`.
- username: `admin`
- password: `Admin@123`

---

## 7) Important APIs (via Gateway)

### Auth
- POST `/auth/api/v1/auth/register/user`
- POST `/auth/api/v1/auth/register/mechanic`
- POST `/auth/api/v1/auth/login`

### Admin
- GET `/mechanics/api/v1/admin/mechanics`
- PATCH `/mechanics/api/v1/admin/mechanics/{id}/status`
- GET `/users/api/v1/admin/users`
- GET `/feedback/api/v1/admin/feedback`

### User
- GET `/mechanics/api/v1/mechanics/search?location=Bangalore`
- POST `/requests/api/v1/requests`

### Mechanic
- GET `/requests/api/v1/requests/me?as=MECHANIC`
- PATCH `/requests/api/v1/requests/{id}/status`

### Feedback
- POST `/feedback/api/v1/feedback`

---

## 8) Tests (No Docker)
Tests run with **H2 in-memory DB** (so they work without Docker).

```bash
mvn test
```

---

## 9) Project Structure (Easy)

```
root (multi-module maven)
  common/
  discovery-server/
  api-gateway/
  auth-service/
  user-service/
  mechanic-service/
  request-service/
  feedback-service/
  infra/sql/create-dbs.sql
```

If you want, I can also add Swagger (OpenAPI) to every service.
