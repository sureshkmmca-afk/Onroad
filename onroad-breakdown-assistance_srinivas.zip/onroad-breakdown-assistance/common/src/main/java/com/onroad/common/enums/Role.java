package com.onroad.common.enums;

public enum Role {
    ADMIN, USER, MECHANIC
}
