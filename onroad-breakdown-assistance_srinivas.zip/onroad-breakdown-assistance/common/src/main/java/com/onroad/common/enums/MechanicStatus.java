package com.onroad.common.enums;

public enum MechanicStatus {
    PENDING,
    APPROVED,
    BLOCKED
}
