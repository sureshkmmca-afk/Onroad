package com.onroad.common.enums;

public enum RequestStatus {
    OPEN,
    ACCEPTED,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}
