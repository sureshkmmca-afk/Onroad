package com.onroad.common.security;

public final class JwtConstants {
    private JwtConstants() {}

    public static final String CLAIM_ROLE = "role";
    public static final String CLAIM_UID = "uid";
}
