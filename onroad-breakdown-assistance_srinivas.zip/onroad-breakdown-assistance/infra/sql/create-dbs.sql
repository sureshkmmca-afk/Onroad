-- Run this once in PostgreSQL
CREATE DATABASE authdb;
CREATE DATABASE userdb;
CREATE DATABASE mechanicdb;
CREATE DATABASE requestdb;
CREATE DATABASE feedbackdb;
