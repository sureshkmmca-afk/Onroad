package com.onroad.feedback;

import com.onroad.common.enums.Role;
import com.onroad.feedback.client.MechanicInternalClient;
import com.onroad.feedback.repo.FeedbackRepository;
import com.onroad.feedback.service.FeedbackService;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class FeedbackServiceTest {

    @Test
    void create_rejects_invalid_rating() {
        FeedbackRepository repo = mock(FeedbackRepository.class);
        MechanicInternalClient client = mock(MechanicInternalClient.class);
        FeedbackService service = new FeedbackService(repo, client);

        assertThatThrownBy(() -> service.create(Role.USER, 1L, Role.MECHANIC, 2L, 10L, 7, "bad"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("rating must be 1..5");
    }
}
