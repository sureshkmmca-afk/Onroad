package com.onroad.feedback.web;

import com.onroad.common.enums.Role;
import com.onroad.common.security.JwtConstants;
import com.onroad.feedback.service.FeedbackService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;

@RestController
@RequestMapping("/api/v1")
@Validated
public class FeedbackController {

    private final FeedbackService service;

    @Value("${security.jwt.secret:change-me-change-me-change-me-change-me}")
    private String secret;

    public FeedbackController(FeedbackService service) {
        this.service = service;
    }

    private Claims claims(String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) throw new IllegalArgumentException("Missing token");
        String token = authHeader.substring(7);
        var key = io.jsonwebtoken.security.Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        return Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload();
    }

    public record CreateFeedback(@NotBlank String toRole, @NotNull Long toId, @NotNull Long requestId,
                                 @NotNull Integer rating, String comment) {}

    @PostMapping("/feedback")
    @PreAuthorize("hasRole('USER') or hasRole('MECHANIC')")
    public Object create(@RequestHeader(HttpHeaders.AUTHORIZATION) String auth, @Validated @RequestBody CreateFeedback req) {
        var c = claims(auth);
        Role fromRole = Role.valueOf(String.valueOf(c.get(JwtConstants.CLAIM_ROLE)));
        Long fromId = Long.valueOf(String.valueOf(c.get(JwtConstants.CLAIM_UID)));
        Role toRole = Role.valueOf(req.toRole());
        return service.create(fromRole, fromId, toRole, req.toId(), req.requestId(), req.rating(), req.comment());
    }
}
