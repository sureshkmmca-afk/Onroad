package com.onroad.feedback.web;

import com.onroad.feedback.repo.FeedbackRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin")
public class AdminFeedbackController {

    private final FeedbackRepository repo;

    public AdminFeedbackController(FeedbackRepository repo) {
        this.repo = repo;
    }

    @GetMapping("/feedback")
    @PreAuthorize("hasRole('ADMIN')")
    public Object all() {
        return repo.findAll();
    }
}
