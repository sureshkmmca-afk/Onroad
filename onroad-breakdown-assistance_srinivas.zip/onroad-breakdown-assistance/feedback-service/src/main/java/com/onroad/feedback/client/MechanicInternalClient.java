package com.onroad.feedback.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "mechanic-service", path = "/api/v1/internal")
public interface MechanicInternalClient {
    @PostMapping("/mechanics/{id}/rating")
    void addRating(@PathVariable("id") Long id,
                    @RequestParam("rating") int rating
    );
}
