package com.onroad.feedback.service;

import com.onroad.common.enums.Role;
import com.onroad.feedback.client.MechanicInternalClient;
import com.onroad.feedback.domain.Feedback;
import com.onroad.feedback.repo.FeedbackRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FeedbackService {

    private final FeedbackRepository repo;
    private final MechanicInternalClient mechanicClient;

    public FeedbackService(FeedbackRepository repo, MechanicInternalClient mechanicClient) {
        this.repo = repo;
        this.mechanicClient = mechanicClient;
    }

    @Transactional
    public Feedback create(Role fromRole, Long fromId, Role toRole, Long toId, Long requestId, int rating, String comment) {
        if (rating < 1 || rating > 5) throw new IllegalArgumentException("rating must be 1..5");
        Feedback f = new Feedback();
        f.setFromRole(fromRole);
        f.setFromId(fromId);
        f.setToRole(toRole);
        f.setToId(toId);
        f.setRequestId(requestId);
        f.setRating(rating);
        f.setComment(comment);
        f = repo.save(f);

        if (toRole == Role.MECHANIC) {
            mechanicClient.addRating(toId, rating);
        }
        return f;
    }
}
