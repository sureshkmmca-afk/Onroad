package com.onroad.feedback.domain;

import com.onroad.common.enums.Role;
import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "feedback")
public class Feedback {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role fromRole;

    @Column(nullable = false)
    private Long fromId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role toRole;

    @Column(nullable = false)
    private Long toId;

    @Column(nullable = false)
    private Long requestId;

    @Column(nullable = false)
    private int rating;

    @Column(length = 2000)
    private String comment;

    @Column(nullable = false)
    private Instant createdAt = Instant.now();

    public Long getId() { return id; }
    public Role getFromRole() { return fromRole; }
    public void setFromRole(Role fromRole) { this.fromRole = fromRole; }
    public Long getFromId() { return fromId; }
    public void setFromId(Long fromId) { this.fromId = fromId; }
    public Role getToRole() { return toRole; }
    public void setToRole(Role toRole) { this.toRole = toRole; }
    public Long getToId() { return toId; }
    public void setToId(Long toId) { this.toId = toId; }
    public Long getRequestId() { return requestId; }
    public void setRequestId(Long requestId) { this.requestId = requestId; }
    public int getRating() { return rating; }
    public void setRating(int rating) { this.rating = rating; }
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    public Instant getCreatedAt() { return createdAt; }
}
