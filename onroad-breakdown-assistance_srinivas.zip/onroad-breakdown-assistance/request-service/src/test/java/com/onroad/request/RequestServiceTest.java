package com.onroad.request;

import com.onroad.common.enums.RequestStatus;
import com.onroad.request.client.MechanicClient;
import com.onroad.request.client.UserClient;
import com.onroad.request.repo.AssistanceRequestRepository;
import com.onroad.request.service.RequestService;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class RequestServiceTest {

    @Test
    void create_fails_when_user_missing() {
        AssistanceRequestRepository repo = mock(AssistanceRequestRepository.class);
        UserClient userClient = mock(UserClient.class);
        MechanicClient mechanicClient = mock(MechanicClient.class);
        when(userClient.exists(1L)).thenReturn(false);

        RequestService service = new RequestService(repo, userClient, mechanicClient);
        assertThatThrownBy(() -> service.create(1L, 2L, "KA01", "flat", "Bangalore"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("User not found");
    }

    @Test
    void updateStatus_updates_entity() {
        AssistanceRequestRepository repo = mock(AssistanceRequestRepository.class);
        UserClient userClient = mock(UserClient.class);
        MechanicClient mechanicClient = mock(MechanicClient.class);

        var r = new com.onroad.request.domain.AssistanceRequest();
        r.setUserId(1L);
        r.setMechanicId(2L);
        r.setVehicleNumber("KA01");
        r.setIssueDescription("flat");
        r.setBreakdownLocation("Bangalore");

        when(repo.findById(10L)).thenReturn(java.util.Optional.of(r));
        when(repo.save(any())).thenAnswer(inv -> inv.getArgument(0));

        RequestService service = new RequestService(repo, userClient, mechanicClient);
        var updated = service.updateStatus(10L, RequestStatus.ACCEPTED);
        assertThat(updated.getStatus()).isEqualTo(RequestStatus.ACCEPTED);
    }
}
