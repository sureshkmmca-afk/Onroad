package com.onroad.request.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "mechanic-service", path = "/api/v1/public")
public interface MechanicClient {

    @GetMapping("/mechanics/{id}/status")
    StatusResponse status(@PathVariable("id") Long id);

    record StatusResponse(String status) {}
}
