package com.onroad.request.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "user-service", path = "/api/v1/internal")
public interface UserClient {
    @GetMapping("/users/{id}/exists")
    Boolean exists(@PathVariable("id") Long id);
}
