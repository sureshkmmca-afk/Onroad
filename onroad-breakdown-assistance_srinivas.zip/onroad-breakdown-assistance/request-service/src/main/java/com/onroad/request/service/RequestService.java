package com.onroad.request.service;

import com.onroad.common.enums.MechanicStatus;
import com.onroad.common.enums.RequestStatus;
import com.onroad.request.client.MechanicClient;
import com.onroad.request.client.UserClient;
import com.onroad.request.domain.AssistanceRequest;
import com.onroad.request.repo.AssistanceRequestRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class RequestService {

    private final AssistanceRequestRepository repo;
    private final UserClient userClient;
    private final MechanicClient mechanicClient;

    public RequestService(AssistanceRequestRepository repo, UserClient userClient, MechanicClient mechanicClient) {
        this.repo = repo;
        this.userClient = userClient;
        this.mechanicClient = mechanicClient;
    }

    @Transactional
    public AssistanceRequest create(Long userId, Long mechanicId, String vehicleNumber, String issue, String location) {
        if (!Boolean.TRUE.equals(userClient.exists(userId))) throw new IllegalArgumentException("User not found");
        var status = mechanicClient.status(mechanicId).status();
        if (!MechanicStatus.APPROVED.name().equals(status)) throw new IllegalArgumentException("Mechanic not approved");

        AssistanceRequest r = new AssistanceRequest();
        r.setUserId(userId);
        r.setMechanicId(mechanicId);
        r.setVehicleNumber(vehicleNumber);
        r.setIssueDescription(issue);
        r.setBreakdownLocation(location);
        r.setStatus(RequestStatus.OPEN);
        return repo.save(r);
    }

    public List<AssistanceRequest> byUser(Long userId) { return repo.findByUserId(userId); }
    public List<AssistanceRequest> byMechanic(Long mechanicId) { return repo.findByMechanicId(mechanicId); }

    @Transactional
    public AssistanceRequest updateStatus(Long requestId, RequestStatus status) {
        var r = repo.findById(requestId).orElseThrow(() -> new IllegalArgumentException("Request not found"));
        r.setStatus(status);
        return repo.save(r);
    }
}
