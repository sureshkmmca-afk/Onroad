package com.onroad.request.repo;

import com.onroad.request.domain.AssistanceRequest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AssistanceRequestRepository extends JpaRepository<AssistanceRequest, Long> {
    List<AssistanceRequest> findByUserId(Long userId);
    List<AssistanceRequest> findByMechanicId(Long mechanicId);
}
