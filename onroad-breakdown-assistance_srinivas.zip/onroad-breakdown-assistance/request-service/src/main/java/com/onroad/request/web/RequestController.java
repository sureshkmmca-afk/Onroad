package com.onroad.request.web;

import com.onroad.common.enums.RequestStatus;
import com.onroad.common.security.JwtConstants;
import com.onroad.request.service.RequestService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;

@RestController
@RequestMapping("/api/v1/requests")
@Validated
public class RequestController {

    private final RequestService service;

    @Value("${security.jwt.secret:change-me-change-me-change-me-change-me}")
    private String secret;

    public RequestController(RequestService service) {
        this.service = service;
    }

    private Long uid(String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) return -1L;
        var token = authHeader.substring(7);
        var key = io.jsonwebtoken.security.Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        Claims c = Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload();
        return Long.valueOf(String.valueOf(c.get(JwtConstants.CLAIM_UID)));
    }

    public record CreateRequest(@NotNull Long mechanicId, @NotBlank String vehicleNumber,
                                @NotBlank String issueDescription, @NotBlank String breakdownLocation) {}

    @PostMapping
    @PreAuthorize("hasRole('USER')")
    public Object create(@RequestHeader(HttpHeaders.AUTHORIZATION) String auth, @Validated @RequestBody CreateRequest req) {
        return service.create(uid(auth), req.mechanicId(), req.vehicleNumber(), req.issueDescription(), req.breakdownLocation());
    }

    @GetMapping("/me")
    @PreAuthorize("hasRole('USER') or hasRole('MECHANIC')")
    public Object my(@RequestHeader(HttpHeaders.AUTHORIZATION) String auth, @RequestParam String as) {
        Long id = uid(auth);
        if ("USER".equalsIgnoreCase(as)) return service.byUser(id);
        return service.byMechanic(id);
    }

    public record UpdateStatus(@NotBlank String status) {}

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasRole('MECHANIC')")
    public Object update(@PathVariable Long id, @Validated @RequestBody UpdateStatus req) {
        return service.updateStatus(id, RequestStatus.valueOf(req.status()));
    }
}
