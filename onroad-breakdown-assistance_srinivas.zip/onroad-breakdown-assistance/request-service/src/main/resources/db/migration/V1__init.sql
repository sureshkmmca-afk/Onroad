CREATE TABLE IF NOT EXISTS assistance_requests (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL,
  mechanic_id BIGINT NOT NULL,
  vehicle_number VARCHAR(50) NOT NULL,
  issue_description VARCHAR(2000) NOT NULL,
  breakdown_location VARCHAR(255) NOT NULL,
  status VARCHAR(50) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL
);
