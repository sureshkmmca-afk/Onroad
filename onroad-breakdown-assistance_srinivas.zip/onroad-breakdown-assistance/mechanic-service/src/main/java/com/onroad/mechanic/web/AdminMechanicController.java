package com.onroad.mechanic.web;

import com.onroad.common.enums.MechanicStatus;
import com.onroad.mechanic.client.AuthClient;
import com.onroad.mechanic.repo.MechanicRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin")
public class AdminMechanicController {

    private final MechanicRepository repo;
    private final AuthClient authClient;

    public AdminMechanicController(MechanicRepository repo, AuthClient authClient) {
        this.repo = repo;
        this.authClient = authClient;
    }

    @GetMapping("/mechanics")
    @PreAuthorize("hasRole('ADMIN')")
    public Object all() {
        return repo.findAll();
    }

    public record UpdateStatusRequest(String status) {}

    @PatchMapping("/mechanics/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public Object updateStatus(@PathVariable Long id, @RequestBody UpdateStatusRequest req) {
        var m = repo.findById(id).orElseThrow(() -> new IllegalArgumentException("Mechanic not found"));
        MechanicStatus status = MechanicStatus.valueOf(req.status());
        m.setStatus(status);
        repo.save(m);
        authClient.setMechanicAccountEnabled(id, status == MechanicStatus.APPROVED);
        return m;
    }
}
