package com.onroad.mechanic.repo;

import com.onroad.common.enums.MechanicStatus;
import com.onroad.mechanic.domain.Mechanic;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface MechanicRepository extends JpaRepository<Mechanic, Long> {
    Optional<Mechanic> findByEmail(String email);
    List<Mechanic> findByLocationIgnoreCaseAndStatus(String location, MechanicStatus status);
}
