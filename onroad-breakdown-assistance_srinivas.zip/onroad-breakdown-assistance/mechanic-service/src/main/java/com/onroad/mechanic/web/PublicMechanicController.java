package com.onroad.mechanic.web;

import com.onroad.mechanic.domain.Mechanic;
import com.onroad.mechanic.repo.MechanicRepository;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/public")
@Validated
public class PublicMechanicController {

    private final MechanicRepository repo;

    public PublicMechanicController(MechanicRepository repo) {
        this.repo = repo;
    }

    public record CreateMechanicRequest(@NotBlank String name, @Email String email, @NotBlank String phone,
                                        @NotBlank String location, @NotBlank String skills) {}
    public record CreateMechanicResponse(Long id) {}
    public record MechanicStatusResponse(String status) {}

    @PostMapping("/mechanics")
    public ResponseEntity<CreateMechanicResponse> create(@Validated @RequestBody CreateMechanicRequest req) {
        repo.findByEmail(req.email()).ifPresent(m -> { throw new IllegalArgumentException("Mechanic already exists"); });
        Mechanic m = new Mechanic();
        m.setName(req.name());
        m.setEmail(req.email());
        m.setPhone(req.phone());
        m.setLocation(req.location());
        m.setSkills(req.skills());
        m = repo.save(m);
        return ResponseEntity.ok(new CreateMechanicResponse(m.getId()));
    }

    @GetMapping("/mechanics/{id}/status")
    public ResponseEntity<MechanicStatusResponse> status(@PathVariable("id")  Long id) {
        var m = repo.findById(id).orElseThrow(() -> new IllegalArgumentException("Mechanic not found"));
        return ResponseEntity.ok(new MechanicStatusResponse(m.getStatus().name()));
    }
}
