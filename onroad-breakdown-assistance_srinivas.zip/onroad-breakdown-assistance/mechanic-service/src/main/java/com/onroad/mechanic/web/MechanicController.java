package com.onroad.mechanic.web;

import com.onroad.common.enums.MechanicStatus;
import com.onroad.mechanic.repo.MechanicRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/mechanics")
public class MechanicController {

    private final MechanicRepository repo;

    public MechanicController(MechanicRepository repo) {
        this.repo = repo;
    }

    @GetMapping("/search")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
    public Object search(@RequestParam String location) {
        return repo.findByLocationIgnoreCaseAndStatus(location, MechanicStatus.APPROVED);
    }
}
