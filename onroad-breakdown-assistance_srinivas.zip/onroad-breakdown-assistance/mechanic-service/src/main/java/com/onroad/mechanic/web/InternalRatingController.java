package com.onroad.mechanic.web;

import com.onroad.mechanic.repo.MechanicRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/internal")
public class InternalRatingController {

    private final MechanicRepository repo;

    public InternalRatingController(MechanicRepository repo) {
        this.repo = repo;
    }

    @PostMapping("/mechanics/{id}/rating")
    public ResponseEntity<Void> addRating(@PathVariable Long id, @RequestParam int rating) {
        var m = repo.findById(id).orElseThrow(() -> new IllegalArgumentException("Mechanic not found"));
        m.updateRating(rating);
        repo.save(m);
        return ResponseEntity.ok().build();
    }
}
