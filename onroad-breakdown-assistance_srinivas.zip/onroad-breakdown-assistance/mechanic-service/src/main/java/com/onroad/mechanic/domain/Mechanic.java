package com.onroad.mechanic.domain;

import com.onroad.common.enums.MechanicStatus;
import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "mechanics")
public class Mechanic {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String phone;

    @Column(nullable = false)
    private String location;

    @Column(nullable = false)
    private String skills;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private MechanicStatus status = MechanicStatus.PENDING;

    @Column(nullable = false)
    private double ratingAvg = 0.0;

    @Column(nullable = false)
    private long ratingCount = 0;

    @Column(nullable = false)
    private Instant createdAt = Instant.now();

    public Long getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getSkills() { return skills; }
    public void setSkills(String skills) { this.skills = skills; }
    public MechanicStatus getStatus() { return status; }
    public void setStatus(MechanicStatus status) { this.status = status; }
    public double getRatingAvg() { return ratingAvg; }
    public long getRatingCount() { return ratingCount; }
    public void updateRating(int rating) {
        double total = ratingAvg * ratingCount;
        ratingCount++;
        ratingAvg = (total + rating) / ratingCount;
    }
}
