package com.onroad.mechanic.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "auth-service", path = "/api/v1/internal")
public interface AuthClient {

    @PostMapping("/mechanics/account-enabled")
    void setMechanicAccountEnabled(@RequestParam("mechanicId") Long mechanicId,
                                   @RequestParam("enabled") boolean enabled);
}
