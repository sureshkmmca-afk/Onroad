package com.onroad.mechanic;

import com.onroad.common.security.SecurityConfigSupport;
import com.onroad.common.web.GlobalExceptionHandler;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
@Import({SecurityConfigSupport.class, GlobalExceptionHandler.class})
public class MechanicServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(MechanicServiceApplication.class, args);
    }
}
