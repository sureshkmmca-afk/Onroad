package com.onroad.mechanic;

import com.onroad.common.enums.MechanicStatus;
import com.onroad.mechanic.domain.Mechanic;
import com.onroad.mechanic.repo.MechanicRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(properties = {
        "spring.datasource.url=jdbc:h2:mem:mechdb;MODE=PostgreSQL;DB_CLOSE_DELAY=-1",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        "spring.jpa.hibernate.ddl-auto=none",
        "spring.flyway.enabled=true",
        "security.jwt.secret=test-test-test-test-test-test-test-test",
        "spring.cloud.openfeign.enabled=false"
})
class MechanicRepositoryTest {

    @Autowired MechanicRepository repo;

    @Test
    void findByLocationAndApproved_returnsOnlyApproved() {
        Mechanic a = new Mechanic();
        a.setName("Mech A");
        a.setEmail("a@mech.com");
        a.setPhone("1");
        a.setLocation("Bangalore");
        a.setSkills("Engine");
        a.setStatus(MechanicStatus.APPROVED);

        Mechanic b = new Mechanic();
        b.setName("Mech B");
        b.setEmail("b@mech.com");
        b.setPhone("2");
        b.setLocation("Bangalore");
        b.setSkills("Tires");
        b.setStatus(MechanicStatus.PENDING);

        repo.save(a);
        repo.save(b);

        var list = repo.findByLocationIgnoreCaseAndStatus("bangalore", MechanicStatus.APPROVED);
        assertThat(list).hasSize(1);
        assertThat(list.getFirst().getEmail()).isEqualTo("a@mech.com");
    }
}
