package com.onroad.discovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoverySmokeTest {
    @Test
    void contextLoads() {}
}
