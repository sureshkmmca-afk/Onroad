package com.onroad.auth;

import com.onroad.auth.client.MechanicClient;
import com.onroad.auth.client.UserClient;
import com.onroad.auth.repo.AccountRepository;
import com.onroad.auth.service.AuthService;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class AuthServiceUnitTest {

    @Test
    void registerUser_fails_when_email_exists() {
        AccountRepository repo = mock(AccountRepository.class);
        when(repo.existsByUsername("a@b.com")).thenReturn(true);
        UserClient userClient = mock(UserClient.class);
        MechanicClient mechClient = mock(MechanicClient.class);

        AuthService service = new AuthService(repo, userClient, mechClient);
        assertThatThrownBy(() -> service.registerUser("A","a@b.com","1","BLR","p"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Email already registered");
    }
}
