package com.onroad.auth.client;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "user-service", path = "/api/v1/public")
public interface UserClient {

    record CreateUserRequest(@NotBlank String name, @Email String email, @NotBlank String phone, @NotBlank String location) {}
    record CreateUserResponse(Long id) {}

    @PostMapping("/users")
    CreateUserResponse createUser(@RequestBody CreateUserRequest request);
}
