package com.onroad.auth.client;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "mechanic-service", path = "/api/v1/public")
public interface MechanicClient {

    record CreateMechanicRequest(@NotBlank String name, @Email String email, @NotBlank String phone, @NotBlank String location, @NotBlank String skills) {}
    record CreateMechanicResponse(Long id) {}

    record MechanicStatusResponse(String status) {}

    @PostMapping("/mechanics")
    CreateMechanicResponse createMechanic(@RequestBody CreateMechanicRequest request);

    @GetMapping("/mechanics/{id}/status")
    MechanicStatusResponse getStatus(@PathVariable("id") Long id);
}
