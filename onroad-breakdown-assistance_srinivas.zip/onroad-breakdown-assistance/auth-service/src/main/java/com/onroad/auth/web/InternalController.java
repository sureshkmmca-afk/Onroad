package com.onroad.auth.web;

import com.onroad.auth.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/internal")
public class InternalController {

    private final AuthService service;

    public InternalController(AuthService service) {
        this.service = service;
    }

    // NOTE: For production secure internal endpoints.
    @PostMapping("/mechanics/account-enabled")
    public ResponseEntity<Void> setEnabled(@RequestParam("mechanicId") Long mechanicId,
                                           @RequestParam("enabled") boolean enabled) {
        service.setAccountEnabledForMechanic(mechanicId, enabled);
        return ResponseEntity.ok().build();
    }
}
