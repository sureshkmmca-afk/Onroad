package com.onroad.auth.web;

import com.onroad.auth.service.AuthService;
import com.onroad.auth.web.dto.AuthDtos;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    private final AuthService service;

    public AuthController(AuthService service) {
        this.service = service;
    }

    @PostMapping("/register/user")
    public ResponseEntity<AuthDtos.RegisterResponse> registerUser(@Validated @RequestBody AuthDtos.RegisterUserRequest req) {
        var acc = service.registerUser(req.name(), req.email(), req.phone(), req.location(), req.password());
        return ResponseEntity.ok(new AuthDtos.RegisterResponse(acc.getId(), acc.getDomainId(), "CREATED"));
    }

    @PostMapping("/register/mechanic")
    public ResponseEntity<AuthDtos.RegisterResponse> registerMechanic(@Validated @RequestBody AuthDtos.RegisterMechanicRequest req) {
        var acc = service.registerMechanic(req.name(), req.email(), req.phone(), req.location(), req.skills(), req.password());
        return ResponseEntity.ok(new AuthDtos.RegisterResponse(acc.getId(), acc.getDomainId(), "PENDING_ADMIN_APPROVAL"));
    }

    @PostMapping("/login")
    public ResponseEntity<AuthDtos.LoginResponse> login(@Validated @RequestBody AuthDtos.LoginRequest req) {
        return ResponseEntity.ok(new AuthDtos.LoginResponse(service.login(req.username(), req.password())));
    }
}
