package com.onroad.auth.web.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public class AuthDtos {

    public record LoginRequest(@NotBlank String username,
                               @NotBlank String password) {}
    public record LoginResponse(String token) {}

    public record RegisterUserRequest(@NotBlank String name,
                                      @Email String email,
                                      @NotBlank String phone,
                                     @NotBlank String location,
                                      @NotBlank String password) {}

    public record RegisterMechanicRequest(@NotBlank String name, @Email String email, @NotBlank String phone,
                                         @NotBlank String location, @NotBlank String skills, @NotBlank String password) {}

    public record RegisterResponse(Long accountId, Long domainId, String status) {}
}
