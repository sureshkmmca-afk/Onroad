package com.onroad.auth.service;

import com.onroad.auth.client.MechanicClient;
import com.onroad.auth.client.UserClient;
import com.onroad.auth.domain.Account;
import com.onroad.auth.repo.AccountRepository;
import com.onroad.common.enums.MechanicStatus;
import com.onroad.common.enums.Role;
import com.onroad.common.security.JwtConstants;
import com.onroad.common.security.JwtUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

@Service
public class AuthService {

    private final AccountRepository repo;
    private final UserClient userClient;
    private final MechanicClient mechanicClient;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    @Value("${security.jwt.secret:change-me-change-me-change-me-change-me}")
    private String secret;

    @Value("${security.jwt.ttlSeconds:86400}")
    private long ttlSeconds;

    public AuthService(AccountRepository repo, UserClient userClient, MechanicClient mechanicClient) {
        this.repo = repo;
        this.userClient = userClient;
        this.mechanicClient = mechanicClient;
    }

    @Transactional
    public Account registerUser(String name, String email, String phone, String location, String rawPassword) {
        if (repo.existsByUsername(email)) throw new IllegalArgumentException("Email already registered");
        var user = userClient.createUser(new UserClient.CreateUserRequest(name, email, phone, location));

        Account acc = new Account();
        acc.setUsername(email);
        acc.setPasswordHash(encoder.encode(rawPassword));
        acc.setRole(Role.USER);
        acc.setEnabled(true);
        acc.setDomainId(user.id());
        return repo.save(acc);
    }

    @Transactional
    public Account registerMechanic(String name, String email, String phone, String location, String skills, String rawPassword) {
        if (repo.existsByUsername(email)) throw new IllegalArgumentException("Email already registered");
        var mech = mechanicClient.createMechanic(new MechanicClient.CreateMechanicRequest(name, email, phone, location, skills));

        Account acc = new Account();
        acc.setUsername(email);
        acc.setPasswordHash(encoder.encode(rawPassword));
        acc.setRole(Role.MECHANIC);
        acc.setEnabled(false); // until approved
        acc.setDomainId(mech.id());
        return repo.save(acc);
    }

    public String login(String username, String rawPassword) {
        Account acc = repo.findByUsername(username).orElseThrow(() -> new IllegalArgumentException("Invalid credentials"));
        if (!encoder.matches(rawPassword, acc.getPasswordHash())) throw new IllegalArgumentException("Invalid credentials");

        if (acc.getRole() == Role.MECHANIC) {
            var status = mechanicClient.getStatus(acc.getDomainId()).status();
            if (!MechanicStatus.APPROVED.name().equals(status)) {
                throw new IllegalArgumentException("Mechanic not approved. Current status: " + status);
            }
        }
        if (!acc.isEnabled()) throw new IllegalArgumentException("Account disabled");

        return JwtUtil.generate(secret, acc.getUsername(), Map.of(
                JwtConstants.CLAIM_ROLE, acc.getRole().name(),
                JwtConstants.CLAIM_UID, acc.getDomainId() == null ? -1 : acc.getDomainId()
        ), ttlSeconds);
    }

    @Transactional
    public void setAccountEnabledForMechanic(Long mechanicId, boolean enabled) {
        repo.findAll().stream()
                .filter(a -> a.getRole() == Role.MECHANIC && mechanicId.equals(a.getDomainId()))
                .findFirst()
                .ifPresent(a -> { a.setEnabled(enabled); repo.save(a); });
    }
}
