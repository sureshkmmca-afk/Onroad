CREATE TABLE IF NOT EXISTS accounts (
  id BIGSERIAL PRIMARY KEY,
  username VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL,
  enabled BOOLEAN NOT NULL,
  domain_id BIGINT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL
);

-- Default admin (password: Admin@123)
INSERT INTO accounts(username, password_hash, role, enabled, domain_id, created_at)
SELECT 'admin', '$2a$10$hng2nBFDpZtOU3xVZcQW..lRkM1j2YV8rTY4WZVpw5wCCfB1GPGjC', 'ADMIN', TRUE, NULL, now()
WHERE NOT EXISTS (SELECT 1 FROM accounts WHERE username='admin');
